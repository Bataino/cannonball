/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rakesh;

import java.io.File;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author Pc User
 */
public class Rakesh extends Application {
    public static Stage stage;
    public static String style = rakesh.Rakesh.class.getResource("css.css").toExternalForm();
    public static File file;
    public static Object[] Circle = new Object[4];
    public static String[] Pyramid = new String[4];
    static HBox status = new HBox();
    @Override
    public void start(final Stage primaryStage) {
        //The Stage , Scene and its Pane , The Menubar
        stage = primaryStage;//stage is used for External Usages within the class
        BorderPane root = new BorderPane();
        MenuBar menubar =  new MenuBar();
        Scene scene = new Scene(root, 300, 250);
        String Db[] = new String[10];
        
        //The Menu and its Separator
        Menu setup = new Menu("File");
        Menu file = new Menu("Setup");
        Menu db = new Menu("Laod from DB");
        SeparatorMenuItem[] sep = new SeparatorMenuItem[10];
        for (int x=0;x<sep.length;x++){
            sep[x] = new SeparatorMenuItem();
        }

        //Defining tMenu Items for File Menu
        final MenuItem lxml = new MenuItem("Load XML");lxml.setOnAction(load(0,"Xml Files",".xml"));
        final MenuItem sxml = new MenuItem("Save XML");sxml.setOnAction(load(1,"Xml Files",".xml"));
        final MenuItem ljson = new MenuItem("Load JSON");ljson.setOnAction(load(0,"Json Files",".json"));
        final MenuItem sjson = new MenuItem("Save JSON");sjson.setOnAction(load(1,"Json Files",".json"));
        final MenuItem des = new MenuItem("DesSerialize");des.setOnAction(load(0,"Ser Files",".ser"));
        final MenuItem ser = new MenuItem("Serialize");ser.setOnAction(load(1,"Ser Files",".ser"));
        
        //Menu Item for Db SubMEnu
        final MenuItem dbmenu[] = new MenuItem[Db.length];
        for(int x=0;x<dbmenu.length;x++){
            dbmenu[x] = new MenuItem(Db[x]);
            db.getItems().add(dbmenu[x]);
        }
         
        
        //Menu Item for Setup Menu
        final MenuItem Pyr = new MenuItem("Pyramid");Pyr.setOnAction(PyramidDialog());
        final MenuItem CBall = new MenuItem("Cannon Ball");CBall.setOnAction(CircleDialog());
        
        //Adding each to MenuButton and he separators
        setup.getItems().addAll(des,ser,sep[0], lxml, sxml,sep[1],ljson,sjson,sep[2],db);
        file.getItems().addAll(Pyr,CBall);
        
        
        menubar.getMenus().add(setup);
        menubar.getMenus().add(file);
        root.setTop(menubar);
        root.setBottom(status);
        
        //The SetId used to calll external css.css and the css file call with the BorderPane
        root.getStylesheets().add(style);
        root.setId("root");
        file.setId("file");
        menubar.setId("menubar");
        
        //Stage Configurations
        primaryStage.setTitle("Cannon Ball");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static EventHandler<ActionEvent> load(final int type,final String ExtensionName, final String... Extension){
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                FileChooser choose = new FileChooser();
                FileChooser.ExtensionFilter chooose = new FileChooser.ExtensionFilter(ExtensionName, Extension);
                choose.getExtensionFilters().add(chooose);
                if(type == 0)
                 file = choose.showOpenDialog(stage);
                else
                file = choose.showSaveDialog(stage);
            }}; 
        
        return event;
    }
    
    
    
     public static EventHandler<ActionEvent> CircleDialog(){
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
               final Stage dialog = new Stage();
               dialog.setTitle("Circle Details");
               VBox root = new VBox();
               Label heading = new Label("Input Details for the Circle");
               HBox head = new HBox();
               head.setStyle("-fx-background-color:#cccccc;-fx-font-size:15;-fx-padding:5;");
               head.getChildren().add(heading);
               Scene scene = new Scene(root, 300, 250);
               scene.getStylesheets().add(style);
               
               HBox hb1 = new HBox();
               HBox hb2 = new HBox();
               HBox hb3 = new HBox();
               HBox hb4 = new HBox();
               
               final TextField radius = new TextField("");
               radius.textProperty().addListener(new ChangeListener<String>(){
                @Override
                    public void changed(ObservableValue<?extends String> observable, String oldv,String newv){
                        if(!newv.matches("\\d{0,9}")){
                            radius.setText(oldv);
                        }
                    }
               });
               Label lb = new Label("Radius :");
               
               final TextField stroke = new TextField("");
               stroke.textProperty().addListener(new ChangeListener<String>(){
                @Override
                    public void changed(ObservableValue<?extends String> observable, String oldv,String newv){
                        if(!newv.matches("\\d{0,9}")){
                            stroke.setText(oldv);
                        }
                    }
               });
               Label lb2 = new Label("Stroke :");
               
               final ChoiceBox color = new ChoiceBox();
               color.getItems().addAll("Blue","Red");
               Label lb3 = new Label("Color  :");
               
               Button ok = new Button("Okay");
               ok.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if(radius.getText() != null && stroke.getText() != null && color.getSelectionModel().getSelectedItem() != null){
                    status();
                    Circle[0] = radius.getText();
                    Circle[1] = stroke.getText();
                    Circle[2] = color.getSelectionModel().getSelectedItem();
                    System.out.println(Circle[0] + "" + Circle[1] + "" + Circle[2]);
                    dialog.close();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Fill the Form Completely to Continue", "Invalid Response", 2);                    
                    }
                }});
               Button cancel = new Button("Cancel");
               
               cancel.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    dialog.close();
                }});
               
               hb1.getChildren().addAll(lb, radius);
               hb1.setId("hbox");
               hb2.getChildren().addAll(lb2, stroke);
               hb2.setId("hbox");
               hb3.getChildren().addAll(lb3, color);
               hb3.setId("hbox");
               hb4.getChildren().addAll(ok, cancel);
               hb4.setAlignment(Pos.CENTER_RIGHT);
               
              
               hb1.setSpacing(10);
               hb2.setSpacing(10);
               hb3.setSpacing(10);
               hb4.setSpacing(15);
               hb4.setStyle("-fx-padding: 30 10;");
               
               root.getChildren().addAll(head,hb1,hb2,hb3,hb4);
               root.setSpacing(10);
               dialog.setScene(scene);
               dialog.initOwner(stage);
               dialog.setResizable(false);
               dialog.initModality(Modality.APPLICATION_MODAL);
               dialog.showAndWait();
            }}; 
        
        return event;
    }

     public static EventHandler<ActionEvent> PyramidDialog(){
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
               final Stage dialog = new Stage();
               dialog.setTitle("SetUp Pyramids");
               VBox root = new VBox();
               Label heading = new Label("Input Specifications for the Pyramid");
               HBox head = new HBox();
               head.setStyle("-fx-background-color:#cccccc;-fx-font-size:15;-fx-padding:5;");
               head.getChildren().add(heading);
               Scene scene = new Scene(root, 300, 250);
               scene.getStylesheets().add(style);
               
               HBox hb1 = new HBox();
               HBox hb2 = new HBox();
               HBox hb3 = new HBox();
               HBox hb4 = new HBox();
               
               final TextField name = new TextField("");
               Label lb = new Label("Name :");
               
               final TextField height = new TextField("");
               height.textProperty().addListener(new ChangeListener<String>(){
                @Override
                    public void changed(ObservableValue<?extends String> observable, String oldv,String newv){
                        if(!newv.matches("\\d{0,9}")){
                            height.setText(oldv);
                        }
                    }
               });
               Label lb2 = new Label("Height:");
               
               final ChoiceBox order = new ChoiceBox();
               order.getItems().addAll("LetJustified","Right");
               Label lb3 = new Label("Order  :");
               
               Button ok = new Button("Okay");
               Button cancel = new Button("Cancel");
               
               cancel.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    dialog.close();
                }});
               ok.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if(name.getText() != null && height.getText() != null && order.getSelectionModel().getSelectedItem() != null){
                    Pyramid[0] = name.getText();
                    Pyramid[1] = height.getText();
                    Pyramid[2] = order.getSelectionModel().getSelectedItem().toString();
                    System.out.println(Pyramid[0] + "" + Pyramid[1] + "" + Pyramid[2]);
                    dialog.close();
                    status();
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Fill the Form Completely to Continue", "Invalid Response", 2);                    
                    }
                }});
               
               hb1.getChildren().addAll(lb, name);
               hb1.setId("hbox");
               hb2.getChildren().addAll(lb2, height);
               hb2.setId("hbox");
               hb3.getChildren().addAll(lb3, order);
               hb3.setId("hbox");
               hb4.getChildren().addAll(ok, cancel);
               hb4.setAlignment(Pos.CENTER_RIGHT);
               
              
               hb1.setSpacing(10);
               hb2.setSpacing(10);
               hb3.setSpacing(10);
               hb4.setSpacing(15);
               hb4.setStyle("-fx-padding: 30 10;");
               
               root.getChildren().addAll(head,hb1,hb2,hb3,hb4);
               root.setSpacing(10);
               dialog.setScene(scene);
               dialog.initOwner(stage);
               dialog.setResizable(false);
               dialog.initModality(Modality.APPLICATION_MODAL);
               dialog.showAndWait();
            }}; 
        
        return event;
    }
     

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static void status(){
        status.getChildren().addAll( new Label("Height :" + Pyramid[1]) , new Label("Stacking Order: " + Pyramid[2]));
        status.setSpacing(20);
        
    }
}
